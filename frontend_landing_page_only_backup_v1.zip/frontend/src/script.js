const typeWriterElement = document.querySelector(".prompt-typewriter");
const typeWriterText = "Build an AI-infrastructure basket of Nvidia, Apple, and TSMC, hedged with 30% US Treasury yield";
let i = 0;
const ctx = document.querySelector('.allocation-chart');


new Chart(ctx, {
    type: 'doughnut',
    data: {
        labels: ['Nvidia', 'Apple', 'TSMC', 'Treasuries'],
        datasets: [{
            data: [30, 25, 20, 25],
            backgroundColor: [
                '#FF6B35',
                '#4D96FF',
                '#6BCB77',
                '#FFD93D'
            ]
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'bottom'
            }
        }
    }
});

function typeWriter() {
    if (i < typeWriterText.length) {
      typeWriterElement.textContent += typeWriterText.charAt(i);
      i += 1;
      setTimeout(typeWriter, 20);
    }
}

typeWriter();
